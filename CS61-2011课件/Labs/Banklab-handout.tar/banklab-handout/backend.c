/*
 * backend.c -- backend for bank simulator: Fall 2010 CS61 Lab 5.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <time.h>
#include <errno.h>
#include <pthread.h>

#include "bank.h"
#include "backend.h"
#include "queue.h"


extern int do_suspicious_reporting; // defined in bank.c

static void delay();
static void grab_reference_lock();
static void release_reference_lock();

// The accounts actually used by the bank code
account accounts[MAX_ACCOUNTS];

// The accounts used for the reference solution
account shadow_accounts[MAX_ACCOUNTS];

pthread_mutex_t print_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t shadow_lock = PTHREAD_MUTEX_INITIALIZER;

double delay_secs = 0.2; 

void init_backend() {
    int i;
    for(i = 0; i < MAX_ACCOUNTS; i++) {
        accounts[i].valid = 0;
        shadow_accounts[i].valid = 0;
    }
}

/*
 * Create account number n with initial balance 0.  Return 0 on
 * success, or ACCOUNT_EXISTS if account already exists.
 */
int do_open_account(int id, int n) {
    shadow_open_account(id, n);

    if (accounts[n].valid == 0) {
        accounts[n].valid = 1;

        /*** deliberate intermediate inconsistency ***/
        accounts[n].balance = 42;
        delay();
        accounts[n].balance = 0;
        return 0;
    } else {
        return ACCOUNT_EXISTS;
    }
}

/*
 * Delete account number n, returning amount of money left.  Return
 * UNKNOWN_ACCOUNT if account doesn't exist (was never created, or has
 * already been closed).
 */
int do_close_account(int id, int n) {
    shadow_close_account(id, n);

    if (accounts[n].valid == 1) {
        int t = accounts[n].balance;

        /*** deliberate intermediate inconsistency ***/
        accounts[n].balance = 42;
        delay();

        // Only set the valid bit to 0 after the delay.
        accounts[n].valid = 0;
        accounts[n].balance = 0;
        return t;
    } else {
        return UNKNOWN_ACCOUNT;
    }
}

/*
 * Deposit amount into account n.  Return UNKNOWN_ACCOUNT if account
 * doesn't exist.
 */
int do_deposit(int id, int n, int amount) {
    shadow_deposit(id, n, amount);
    
    if (accounts[n].valid == 1) {
        int t = accounts[n].balance;

        /*** deliberate intermediate inconsistency ***/
        accounts[n].balance = 42;
        delay();

        accounts[n].balance = t + amount;
        
        return accounts[n].balance;
    } else {
        return UNKNOWN_ACCOUNT;
    }
}

/*
 * Withdraw amount from account n.  Return UNKNOWN_ACCOUNT if account
 * doesn't exist.  Return INSUFFICIENT_FUNDS if the balance is less
 * than amount.
 */
int do_withdraw(int id, int n, int amount) {
    shadow_withdraw(id, n, amount);
    
    if (accounts[n].valid == 1) {
        if (accounts[n].balance >= amount) {
            int t = accounts[n].balance;

            /*** deliberate intermediate inconsistency ***/
            accounts[n].balance = 42;
            delay();

            accounts[n].balance = t - amount;

            return accounts[n].balance;
        } else {
            return INSUFFICIENT_FUNDS;
        }
    } else {
        return UNKNOWN_ACCOUNT;
    }
}

/*
 * Return the balance in account n.  Return UNKNOWN_ACCOUNT if account
 * doesn't exist.
 */
int do_get_balance(int id, int n) {
    shadow_get_balance(id, n);
    
    /* Add some delay, but reads aren't allowed to modify the state,
     * so no intermediate inconsistencies here. */
    int t = accounts[n].balance;  // but do read into a local and then wait a while
    // make reads slow so we actually get some benefit from adding simultaneous readers. 
    delay();  
    delay();

    if(accounts[n].valid == 1) {
        return t;
    } else {
        return UNKNOWN_ACCOUNT;
    }
}

/*
 * Transfer amount from account "from" to account "to".  Return
 * UNKNOWN_ACCOUNT if either doesn't exist.  Return INSUFFICIENT_FUNDS
 * if "from" has balance less than amount.
 */
int do_transfer(int id, int from, int to, int amount) {
    shadow_transfer(id, from, to, amount);
    
    /*** deliberate intermediate inconsistency: totally mess with
     * everything ***/
    int v0 = accounts[from].valid;
    int v1 = accounts[to].valid;
    int b0 = accounts[from].balance;
    int b1 = accounts[to].balance;

    accounts[from].valid = !v0;
    accounts[from].balance += 1000;
    accounts[to].valid = !v1;
    accounts[to].balance /= 2;
    
    delay();

    accounts[from].valid = v0;
    accounts[from].balance = b0;
    accounts[to].valid = v1;
    accounts[to].balance = b1;

    if (accounts[from].valid == 0 || accounts[to].valid == 0) {
        return UNKNOWN_ACCOUNT;
    }

    if (accounts[from].balance < amount) {
        return INSUFFICIENT_FUNDS;
    }

    accounts[from].balance = 42;
    accounts[to].balance = 66;
    delay();
    
    accounts[from].balance = b0 - amount;

    delay(); 
    accounts[to].balance = b1 + amount;
    return accounts[from].balance;
}

/*
 * Return a Queue of balance structs, one for each active account in
 * the system.  Note that this report must be consistent with the
 * state of the system at a particular point--if there have been $X
 * deposits and $Y withdrawals so far, the total must be $X-$Y, for
 * example.
 */
Queue do_report_balances(int id) {
    shadow_report_balances(id);

    Queue q = q_new();
    int i;
    for (i = 0; i < MAX_ACCOUNTS; i++) {
        if (accounts[i].valid) {
            balance* b = Malloc(sizeof(struct balance));
            b->n = i;
            b->amount = accounts[i].balance;
            q_add(q, b);
        }
    }
    return q;
}

void do_log_suspicious_activity(transfer_info t) {
    sync_printf("SUSPICIOUS_TRANSFER %d %d %d\n", t.from, t.to, t.amount);
}

void do_log_final_state() {
    sync_printf("\n==== Final check: =======\n");
    int i;
    for (i = 0; i < MAX_ACCOUNTS; i++) {
        if (accounts[i].valid != shadow_accounts[i].valid) {
            sync_printf("BUG: Valid bit mismatch for account %d:  Actual %d; Expected %d\n",
                        i, accounts[i].valid, shadow_accounts[i].valid);
        } else if(accounts[i].valid) {
            if(accounts[i].balance != shadow_accounts[i].balance) {
                sync_printf("BUG: Balance mismatch for account %d:  Actual %d; Expected %d\n",
                        i, accounts[i].balance, shadow_accounts[i].balance);
            } else {
                sync_printf("Final balance for account %d: %d\n", i, accounts[i].balance);
            }
        }
    }
}

/*************************************
 * Some miscellaneous helper routines
 ************************************/

void grab_print_lock() {
    if(0 != pthread_mutex_lock(&print_lock)) {
      fatal_error("Error locking print_lock");
    }
}

void release_print_lock() {
    if(0 != pthread_mutex_unlock(&print_lock)) {
       fatal_error("Error unlocking print_lock");
    }
}


/*
 * A synchronized printf--make sure only one thread at a time can
 * print things.  Also prints a timestamp.
 *
 * For more info on wrapping variable argument functions in C:
 * http://c-faq.com/varargs/handoff.html
 */
void sync_printf(const char* format, ...) {
    va_list args;

    grab_print_lock();
    
    // forward the call to printf
    va_start(args, format);
    vprintf(format, args);
    fflush(stdout);
    va_end(args);

    release_print_lock();
}

/*
 * Print the message, pre-pending the bank name,
 * and still under the print lock.
 */
void bank_printf(const char* format, ...) {
    va_list args;

    // grab the lock
    if(0 != pthread_mutex_lock(&print_lock)) {
      fatal_error("Error locking print_lock");
    }

    printf("%-12s", bank_name);
    
    // forward the call
    va_start(args, format);
    vprintf(format, args);
    fflush(stdout);
    va_end(args);

    // release the lock
    if(0 != pthread_mutex_unlock(&print_lock)) {
       fatal_error("Error unlocking print_lock");
    }
}

/*
 * Print the message, prepending "REFERENCE: "
 * and still under the print lock.
 */
void ref_printf(const char* format, ...) {
    va_list args;

    // grab the lock
    if(0 != pthread_mutex_lock(&print_lock)) {
      fatal_error("Error locking print_lock");
    }

    printf("%-12s", "REFERENCE: ");
    
    // forward the call
    va_start(args, format);
    vprintf(format, args);
    fflush(stdout);
    va_end(args);

    // release the lock
    if(0 != pthread_mutex_unlock(&print_lock)) {
       fatal_error("Error unlocking print_lock");
    }

}

static void grab_reference_lock() {
    if(0 != pthread_mutex_lock(&shadow_lock)) {
      fatal_error("Error locking shadow_lock");
    }
}


static void release_reference_lock() {
    if(0 != pthread_mutex_unlock(&shadow_lock)) {
      fatal_error("Error unlocking shadow_lock");
    }
}

/*
 * Randomly delay the operation a bit.  Used to help expose threading
 * bugs by introducing broken intermediate state that other threads shouldn't see
 * if locking is done properly.
 */
static void delay() {
    random_sleep(delay_secs / 2, delay_secs * 3.0/2);
}

/*
 * Sleep for a random amount of time between the specified min and max, specified in
 * seconds.
 */
void random_sleep(double min_secs, double max_secs)
{
    if (max_secs == 0) {
        return;
    }
    if (min_secs > max_secs) {
        fatal_error("random_sleep(min, max) called with max < min");
    }
    
    // Get a random number between 0 and 1
    double r = random()/( ((double)RAND_MAX)+1);

    double sleep_seconds = min_secs + r * (max_secs - min_secs);
    if(usleep((unsigned)(sleep_seconds * 1e6)) == -1 && errno != EINTR) {
        // Don't care if the sleep is interrupted by signal.  But
        // otherwise, something is actually wrong
        unix_error("usleep");
    }
    
}

/*
 * Get the time from gettimeofday and return it as a single long long val:
 * microseconds since the epoch.
 */
unsigned long long gettime_usecs()
{
    struct timeval tp;
    if(-1 == gettimeofday(&tp, NULL)) {
        unix_error("gettimeofday");
    }
    long long result = tp.tv_sec * 1e6 + tp.tv_usec;
    return result;
}

/*
 * Wrap the libc malloc and quit on any errors
 */
void* Malloc(size_t n) {
    void* t = malloc(n);
    if(t)
        return t;
    unix_error("malloc");

    // Just to make the compiler happy--will never actually get here
    return NULL;  
}

/*
 * Wrap the libc calloc and quit on any errors
 */
void* Calloc(size_t n, size_t size) {
    void* t = calloc(n, size);
    if(t)
        return t;
    unix_error("calloc");

    // Just to make the compiler happy--will never actually get here
    return NULL;  
}

/*
 * print an error message (including an extra newline) and exit
 */
void fatal_error(char* format, ...)
{
    va_list args;

    va_start(args, format);
    vfprintf(stderr, format, args);
    va_end(args);
    fprintf(stderr, "\n");

    exit(1);
}

/* 
 * unix_error - Report a Unix-style error
 */
void unix_error(char *msg) 
{
    printf("%s: %s\n", msg, strerror(errno));
    exit(1);
}

/*
 * Check that min <= val <= max.  Print error msg and die otherwise.
 */
void check_range(int val, int min, int max, char* varname) {
    if(val < min || val > max) {
        fprintf(stderr, "ERROR: %s=%d not in range [%d, %d]\n",
                varname, val, min, max);
        exit(1);
    }
}

/*
 * Split str into tokens.  Returns the array of tokens, and the number
 * in n.  The split is done in place, so str _must_ point to
 * modifiable memory.  (tokenize("fixed str" ..) will result in Bus
 * Errors and other nasty troubles.  Will skip any empty tokens.
 */
char** tokenize(char* str, int* n) {
    char *token;
    char **result;
    int MAX = 10;      // 10 tokens should be more than enough

    const char delimiters[] = " \t\n";
    
    int k = 0;

    result = Malloc(MAX * sizeof(char*));
    do {
        token = strsep(&str, delimiters);
//        printf("DEBUG: token %d: %s\n", k, token);
        if(token != NULL && *token != 0) {
            result[k++] = token;
        }
    } while (token != NULL && k < MAX);

    *n = k;
    return result;
}


void test_tokenize() {
    char* s = "withdraw  0 50\n";
    int n;
    char* copy = Malloc(strlen(s) + 1);
    strcpy(copy, s);
    
    char** tokens = tokenize(copy, &n);
    int i;
    printf("n = %d\n", n);
    for(i=0; i < n; i++) {
        printf("token %d: '%s'\n", i, tokens[i]);
    }
    check_range(n, 3, 3, "num_tokens");
}

operation* new_op(int type) {
    operation* op = Malloc(sizeof(struct operation));
    op->type = type;
    op->account = -1;
    op->account2 = -1;
    op->amount = -1;
    return op;
}

operation* new_unary_op(int type, int account) {
    operation* op = Malloc(sizeof(struct operation));
    op->type = type;
    op->account = account;
    op->account2 = -1;
    op->amount = -1;
    return op;
}

operation* new_binary_op(int type, int account, int amount) {
    operation* op = Malloc(sizeof(struct operation));
    op->type = type;
    op->account = account;
    op->account2 = -1;
    op->amount = amount;
    return op;
}

operation* new_ternary_op(int type, int from, int to, int amount) {
    operation* op = Malloc(sizeof(struct operation));
    op->type = type;
    op->account = from;
    op->account2 = to;
    op->amount = amount;
    return op;
}

/*****************************
 * The Shadow Banking System *
 ****************************/

void shadow_open_account(int id, int n) {
    grab_reference_lock();

    int r = shadow_accounts[n].valid ? ACCOUNT_EXISTS : 0;
    ref_printf("<%d> open %d -- %d\n", id, n, r);

    if (shadow_accounts[n].valid == 0) {
        shadow_accounts[n].valid = 1;
        shadow_accounts[n].balance = 0;
    }
    
    release_reference_lock();
}

void shadow_close_account(int id, int n) {
    grab_reference_lock();

    int r = shadow_accounts[n].valid ? shadow_accounts[n].balance : UNKNOWN_ACCOUNT;
    ref_printf("<%d> close %d -- %d\n", id, n, r);

    if (shadow_accounts[n].valid == 1) {
        shadow_accounts[n].valid = 0;
        shadow_accounts[n].balance = 0;
    }
    
    release_reference_lock();
}

void shadow_deposit(int id, int n, int amount) {
    grab_reference_lock();
    
    int r = shadow_accounts[n].valid ? shadow_accounts[n].balance + amount : UNKNOWN_ACCOUNT;
    ref_printf("<%d> deposit %d %d -- %d\n", id, n, amount, r);

    if (shadow_accounts[n].valid == 1) {
        int t = shadow_accounts[n].balance;
        shadow_accounts[n].balance = t + amount;
    }

    release_reference_lock();
}

void shadow_withdraw(int id, int n, int amount) {
    grab_reference_lock();

    int r;
    if (shadow_accounts[n].valid) {
        if (shadow_accounts[n].balance >= amount) {
            r = shadow_accounts[n].balance - amount;
        } else {
            r = INSUFFICIENT_FUNDS;
        }
    } else {
        r = UNKNOWN_ACCOUNT;
    }
    ref_printf("<%d> withdraw %d %d -- %d\n", id, n, amount, r);

    if (shadow_accounts[n].valid == 1) {
        if (shadow_accounts[n].balance >= amount) {
            int t = shadow_accounts[n].balance;
            shadow_accounts[n].balance = t - amount;
        }
    }
    
    release_reference_lock();
}

void shadow_get_balance(int id, int n) {
    // Figure out and log what should happen if the world were locked.
    grab_reference_lock();
    int r = shadow_accounts[n].valid ? shadow_accounts[n].balance : UNKNOWN_ACCOUNT;
    ref_printf("<%d> get_balance %d -- %d\n", id, n, r);
    release_reference_lock();
}


void shadow_transfer(int id, int from, int to, int amount) {
    grab_reference_lock();

    int r;
    if (shadow_accounts[from].valid && shadow_accounts[to].valid) {
        if (shadow_accounts[from].balance >= amount) {
            r = shadow_accounts[from].balance - amount;
        } else {
            r = INSUFFICIENT_FUNDS;
        }
    } else {
        r = UNKNOWN_ACCOUNT;
    }
    ref_printf("<%d> transfer %d %d %d -- %d\n", id, from, to, amount, r);

    if (do_suspicious_reporting && transfer_is_suspicious(r, amount)) {
        ref_printf("<%d> SUSPICIOUS TRANSFER from %d to %d: $%d\n",
                   id, from, to, amount);
    }
    if (shadow_accounts[from].valid && shadow_accounts[to].valid &&
        shadow_accounts[from].balance >= amount)
    {
        shadow_accounts[from].balance -= amount;
        shadow_accounts[to].balance += amount;
    }
    
    release_reference_lock();
    
}

void shadow_report_balances(id) {
    grab_reference_lock();
    grab_print_lock();
    printf("%-12s <%d> report_balances: ", "REFERENCE: ", id);
    int i;
    for(i = 0; i < MAX_ACCOUNTS; i++) {
        if(shadow_accounts[i].valid) {
            printf("%d  %d; ", i, shadow_accounts[i].balance);
        }
    }
    printf("\n");
    release_print_lock();
    release_reference_lock();
}


