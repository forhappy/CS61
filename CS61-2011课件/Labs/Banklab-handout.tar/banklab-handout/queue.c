#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "queue.h"

int q_empty(Queue q) {
    return q_size(q) == 0;
}

int q_size(Queue q) {
    assert(q);
    return q->size;
}

Queue q_new(void) {
    Queue q;
    if((q = malloc(sizeof(struct queue))) == NULL)
        return NULL;
    q->front = NULL;
    q->back = NULL;
    q->size = 0;
    return q;
}

QueueItem q_add(Queue q, void *data) {
    QueueItem newitem;
    if(q == NULL)
        return NULL;
    if((newitem = malloc(sizeof(struct QueueItem))) == NULL)
        return NULL;
    newitem->data = data;
    newitem->queue = q;
    newitem->next = NULL;
    newitem->prev = NULL;
    if(q->size == 0)
        q->front = newitem;
    else {
        newitem->prev = q->back;
        q->back->next = newitem;
    }
    q->back = newitem;
    q->size++;
    return newitem;
}

QueueItem q_add_to_front(Queue q, void *data) {
    QueueItem newitem;
    if(q == NULL)
        return NULL;
    if((newitem = malloc(sizeof(struct QueueItem))) == NULL)
        return NULL;
    newitem->data = data;
    newitem->queue = q;
    newitem->next = NULL;
    newitem->prev = NULL;
    if(q->size == 0)
        q->back = newitem;
    else {
        newitem->next = q->front;
        q->front->prev = newitem;
    }
    q->front = newitem;
    (q->size)++;
    return newitem;
}


void* q_get_front(Queue q) {
    if(q == NULL)
        return NULL;
    if(q->size == 0)
        return NULL;
    return q->front->data;
}

void* q_get_back(Queue q) {
    if(q == NULL)
        return NULL;
    if(q->size == 0)
        return NULL;
    return q->back->data;
}

/*
 * Remove item from the queue it's in.
 */
void *q_delete(QueueItem item) {
    Queue q;
    void *returneddata;
    if(item == NULL)
        return NULL;
    q = item->queue;
    if(q->front == item)
        q->front = item->next;
    else
        item->prev->next = item->next;
    if(q->back == item)
        q->back = item->prev;
    else
        item->next->prev = item->prev;
    returneddata = item->data;
    (q->size)--;
    free(item);
    return returneddata;
}

/* Pop the next element off the front of the queue and return the data */
void *q_next(Queue q) {
    QueueItem removeditem;
    void *returneddata;
    if(q == NULL)
        return NULL;
    if(q->size == 0)
        return NULL;
    if(q->back == q->front)
        q->back = NULL;
    removeditem = q->front;
    q->front = q->front->next;
    returneddata = removeditem->data;
    (q->size)--;
    free(removeditem);
    return returneddata;
}

/*
 * Free all the nodes in the queue.
 */
void q_free(Queue q) {
    QueueItem curitem, nextitem;
    if(q == NULL)
        return;
    for(curitem = q->front; curitem != NULL && (q->size > 0); curitem = nextitem) {
        nextitem = curitem->next;
        free(curitem);
        (q->size)--;
    }
    free(q);
    return;
}

/* Print the data pointers in each queue node. */
void q_print(Queue q) {
    QueueItem curitem;
    int size;
    if(q == NULL)
        return;
    size = q->size;
    fprintf(stderr,"Printing queue\n");
    for(curitem = q->front; curitem != NULL && (size > 0); curitem = curitem->next) {
        fprintf(stderr,"0x%x;", (int)curitem->data);
        size--;
    }
    fprintf(stderr,"\n");
    return;
}
