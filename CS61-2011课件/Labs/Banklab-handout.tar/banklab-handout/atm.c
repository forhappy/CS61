/* 
 * atm.c -- main() and client code for bank simulator.
 * Fall 2010 CS61 Lab 5.
 * 
 *
 * NOTE: You should NOT MODIFY any of the code in this file.  You should only ADD code.
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <time.h>
#include <errno.h>
#include <pthread.h>

#include "bank.h"
#include "backend.h"
#include "queue.h"

char* bank_name = "GSB:";
extern int locking_type; // defined in bank.c
extern int do_suspicious_reporting; // defined in bank.c

/* Set via the -v parameter.  Feel free to use for controlling level of
 * debugging output */
int verbose = 0;

static int request_delay_ms = DEFAULT_REQUEST_DELAY_MS;
static int num_threads = DEFAULT_NUM_THREADS;
static int seed;

/* function prototypes */
void* simulate_atm(void* info);
void do_operation(operation* op);
void print_operation(operation* op);

void print_balances(Queue balances, int id);
static void average_delay(int avg_ms);

void parse_options(int argc, char** argv);
void usage();
Queue read_trace();

/*
 * main - Parse args, init data structures, start atm threads.
 */
int main(int argc, char** argv)
{
    int i;
    Queue operations;
    // Default random seed:
    seed = time(NULL);

    parse_options(argc, argv);

    if (verbose) sync_printf("Reading trace\n");
    operations = read_trace();
    if (verbose) sync_printf("DONE reading trace\n");

    int num_ops = q_size(operations);
    // Seed the random number generator to make it possible to make
    // the runs a bit more predictable.
    srandom(seed);
    
    sync_printf("Today's bank scenario:\n");
    sync_printf("LOG: %d atm threads\n", num_threads);
    sync_printf("LOG: avg time between operations: %d (msec)\n", request_delay_ms);
    sync_printf("LOG: %d total operations\n", q_size(operations));
    sync_printf("LOG: locking mode %d\n", locking_type);
    sync_printf("LOG: random seed %d\n", seed);
    sync_printf("\n");

    /* Initialize the bank */
    init_backend();
    init_bank();

    /* Set up the info for each thread--in particular, divvy up the
     * requests among them in a round-robin order */
    atm_info* thread_info = Malloc(sizeof(struct atm_info) * num_threads);
    
    for(i = 0; i < num_threads; i++) {
        atm_info* info = &thread_info[i];
        info->id = i;
        info->requests = q_new();
        info->request_delay_ms = request_delay_ms;
    }

    if (verbose) sync_printf("LOG: Divvying up requests to thread queues\n");

    int t = 0;
    while(!q_empty(operations)) {
        q_add(thread_info[t].requests, q_next(operations));
        t = (t + 1) % num_threads;  
    }
    // Clean up the queue struct itself
    q_free(operations);

    if (verbose) sync_printf("LOG: Starting threads\n");

    unsigned long long start = gettime_usecs();

    /* If needed, create the suspicious activity thread */
    if(do_suspicious_reporting){
        pthread_t sa_thread;
        if(pthread_create(&sa_thread, NULL, suspicious_activity_thread, NULL)) {
            fatal_error("Couldn't create suspicious_activity_thread");
        }
    }
    
    /* Actually create atm threads */
    pthread_t* threads = Malloc(sizeof(pthread_t) * num_threads);

    for(i = 0; i < num_threads; i++) {
        if(pthread_create(&threads[i], NULL, simulate_atm, &thread_info[i]) != 0) {
            fatal_error("Couldn't create atm thread");
        }
    }        
    
    // Wait for all of them to finish
    for(i = 0; i < num_threads; i++) {
        if(0 != pthread_join(threads[i], NULL)) {
            fatal_error("atm thread join");
        }
    }

    unsigned long long end = gettime_usecs();
    double total_time = (end - start) / 1.0e6;

 
    printf("======== ALL DONE =======\n");
    printf("Took %.1f seconds to process %d ops: %.1f requests ops/sec\n",
           total_time, num_ops, num_ops/total_time);

    // Ok, all threads are done.  Get the final state.
    do_log_final_state();

    // Just to be tidy, free things:
    for(i = 0; i < num_threads; i++) {
        q_free(thread_info[i].requests);
    }
    free(thread_info);
    
    return 0;
}


/*************************************
 * The ATM simulation code
 ************************************/

/*
 * The code for each ATM thread.  Process the requests, waiting a bit between them. 
 */
void* simulate_atm(void* info) {
    atm_info* config = (atm_info*)info;

    if (verbose)
        sync_printf("LOG: atm %d starting in: %d requests, delay %d\n",
                    config->id, q_size(config->requests), config->request_delay_ms);

    while(!q_empty(config->requests)) {
        operation* op = (operation*)q_next(config->requests);
        do_operation(op);
        average_delay(config->request_delay_ms);
    }
    // For some reason the joins above seem to return before output is
    // flushed at the very end of the trace.  Adding a short sleep
    // seems to fix it.  (behavior on OS X -- no data on linux yet)
    sleep(1);
    return NULL;
}

/*
 * Run the specified operation by forwarding the call to the implementation in bank.c.
 * Log the result.
 */
void do_operation(operation* op) {
    Queue balances;
    int result;
    switch(op->type) {
    case OP_OPEN:
        result = open_account(op->id, op->account);
        bank_printf("[%d] OPEN %d -- %d\n", op->id, op->account, result);
        break;
    case OP_CLOSE:
        result = close_account(op->id, op->account);
        bank_printf("[%d] CLOSE %d -- %d\n", op->id, op->account, result);
        break;
    case OP_BALANCE:
        result = get_balance(op->id, op->account);
        bank_printf("[%d] GET_BALANCE %d -- %d\n", op->id, op->account, result);
        break;
    case OP_DEPOSIT:
        result = deposit(op->id, op->account, op->amount);
        bank_printf("[%d] DEPOSIT %d %d -- %d\n", op->id, op->account, op->amount, result);
        break;
    case OP_WITHDRAW:
        result = withdraw(op->id, op->account, op->amount);
        bank_printf("[%d] WITHDRAW %d %d -- %d\n", op->id, op->account, op->amount, result);
        break;
    case OP_REPORT:
        balances = report_balances(op->id);
        print_balances(balances, op->id);
        q_free(balances);
        break;
    case OP_TRANSFER:
        result = transfer(op->id, op->account, op->account2, op->amount);
        bank_printf("[%d] TRANSFER %d %d %d -- %d\n", op->id,
                     op->account, op->account2, op->amount, result);
        break;
    default:
        fatal_error("Unknown operation type: %d", op->type);
    }
}

/* Print all the reported balances while holding the print lock */
void print_balances(Queue balances, int id) {
    grab_print_lock();
    printf("%-12s [%d] REPORT_BALANCES: ", bank_name,id);
    if(balances == NULL) 
        fatal_error("Balances null");
    
    while(!q_empty(balances)) {
        balance* b = q_next(balances);
        printf("%d  %d; ", b->n, b->amount);
    }
    printf("\n");
    release_print_lock();

}

/*************************************
 * Helper routines
 ************************************/

static void average_delay(int avg_ms) {
    double avg_secs = avg_ms / 1000.0;
    random_sleep(avg_secs / 2, 3 * avg_secs / 2);
}

/*
 * usage - print a help message
 */
void usage(void) 
{
    printf("Usage: bank [-hv] [-n <num threads>] [-r <delay between requests>] [-s seed] [-l locking-mode]\n");
    printf("   -h   Print this message\n");
    printf("   -l   Locking mode: \n");
    printf("        0--No locks\n");
    printf("        1--One Big Lock\n");
    printf("        2--Fine grained\n");
    printf("        3--Multiple readers (default)\n");
    printf("   -u   Report suspicious transfers\n");
    printf("   -n   Number of atm threads to simulate (default %d)\n", DEFAULT_NUM_THREADS);
    printf("   -r   Average time between requests (ms) (default %d)\n", DEFAULT_REQUEST_DELAY_MS);
    printf("   -s   Seed for random number generator\n");
    printf("   -v   Print additional diagnostic information\n");
    exit(1);
}

/* Parse the command line, storing results in global vars */
void parse_options(int argc, char** argv) {
    char c;
    
    while ((c = getopt(argc, argv, "hvn:r:m:s:t:l:u")) != EOF) {
        switch (c) {
        case 'h':             /* print help message */
            usage();
            break;
        case 'v':             /* emit additional diagnostic info */
            verbose = 1;
            break;
        case 'n':             /* num threads */
            num_threads = strtol(optarg, NULL, 10);
            if(num_threads <= 0) {
                fatal_error("Num threads must be > 0");
            }
            break;
        case 'r':             /* average delay between requests */
            request_delay_ms = strtol(optarg, NULL, 10);
            if(request_delay_ms <= 0) {
                fatal_error("Request delay must be > 0");
            }
            break;
        case 's':             /* Random seed */
            seed = strtol(optarg, NULL, 10);
            break;
        case 'l':             /* Locking mode */
            locking_type = strtol(optarg, NULL, 10);
            if(locking_type < 0 || locking_type > 3) {
                fatal_error("Locking mode must be between 0 and 3");
            }
            break;
        case 'u':
            do_suspicious_reporting = 1;
            break;
        default:
            usage();
        }
    }
}

/*
 * Read the operations trace from stdin.  Returns a queue of requests.
 */   
Queue read_trace() {
    Queue q = q_new();
    char line[MAXLINE];
    char copy[MAXLINE];
    int id = 0;
    char** tokens;
    int n;

    int account;
    int amount;

    int linenum = 0;
    
    while(!feof(stdin)) {
        char* s = fgets(line, MAXLINE, stdin);
        if (ferror(stdin)) {
            printf("fgets error\n");
            exit(1);
        }
        if(s == NULL) {
            continue;
        }
        
        linenum++;

        strcpy(copy, line);
        tokens = tokenize(copy, &n);
//        printf("line '%s' has %d tokens\n", line, n);
        if (n == 0) {
            // skip empty lines
            continue;
        }

        operation* op = NULL;
        
        if(strcasecmp(tokens[0], "open") == 0) {
            // "open <n>"
            if(n != 2) fatal_error("Syntax error on line %d", linenum);
            account = strtol(tokens[1], NULL, 10);
            op = new_unary_op(OP_OPEN, account);
            
        } else if(strcasecmp(tokens[0], "close") == 0) {
            // "close <n>"
            if(n != 2) fatal_error("Syntax error on line %d", linenum);
            account = strtol(tokens[1], NULL, 10);
            op = new_unary_op(OP_CLOSE, account);
            
        } else if(strcasecmp(tokens[0], "get_balance") == 0) {
            // "get_balance <n>"
            if(n != 2) fatal_error("Syntax error on line %d", linenum);
            account = strtol(tokens[1], NULL, 10);
            op = new_unary_op(OP_BALANCE, account);
            
        } else if(strcasecmp(tokens[0], "deposit") == 0) {
            // "deposit_balance <n> <amount>"
            if(n != 3) fatal_error("Syntax error on line %d", linenum);
            account = strtol(tokens[1], NULL, 10);
            amount = strtol(tokens[2], NULL, 10);
            op = new_binary_op(OP_DEPOSIT, account, amount);
            
        } else if(strcasecmp(tokens[0], "withdraw") == 0) {
            // "withdraw <n> <amount>"
            if(n != 3) fatal_error("Syntax error on line %d", linenum);
            account = strtol(tokens[1], NULL, 10);
            amount = strtol(tokens[2], NULL, 10);
            op = new_binary_op(OP_WITHDRAW, account, amount);
            
        } else if(strcasecmp(tokens[0], "report") == 0) {
            // "report"
            if(n != 1) fatal_error("Syntax error on line %d", linenum);
            op = new_op(OP_REPORT);
            
        } else if(strcasecmp(tokens[0], "transfer") == 0) {
            // "transfer <from> <to> <amount>"
            if(n != 4) fatal_error("Syntax error on line %d", linenum);
            int from = strtol(tokens[1], NULL, 10);
            int to = strtol(tokens[2], NULL, 10);
            int amount = strtol(tokens[3], NULL, 10);
            op = new_ternary_op(OP_TRANSFER, from, to, amount);
        } // Skipping any other lines
        if(op != NULL) {
            if(verbose)
                print_operation(op);
            op->id = id++;
            q_add(q, op);
        }
             
    }    
    return q;
}

void print_operation(operation* op) {
    switch(op->type) {
    case OP_OPEN:
        bank_printf("OPEN %d\n", op->account);
        break;
    case OP_CLOSE:
        bank_printf("CLOSE %d\n", op->account);
        break;
    case OP_BALANCE:
        bank_printf("GET_BALANCE %d\n", op->account);
        break;
    case OP_DEPOSIT:
        bank_printf("DEPOSIT %d %d\n", op->account, op->amount);
        break;
    case OP_WITHDRAW:
        bank_printf("WITHDRAW %d %d\n", op->account, op->amount);
        break;
    case OP_REPORT:
        bank_printf("REPORT_BALANCES\n");
        break;
    case OP_TRANSFER:
        bank_printf("TRANSFER %d %d %d \n",
                     op->account, op->account2, op->amount);
        break;
    default:
        fatal_error("Unknown operation type: %d", op->type);
    }
}
