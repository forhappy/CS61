/* 
 * backend.h
 * Fall 2010 CS61 Lab 5.
 */

#ifndef BACKEND_H
#define BACKEND_H


operation* new_op(int type);
operation* new_unary_op(int type, int account);
operation* new_binary_op(int type, int account, int amount);
operation* new_ternary_op(int type, int from, int to, int amount);

void init_backend();

void grab_print_lock();
void release_print_lock();

// Used after all the atm have finished to see what your system has wraught.
void do_log_final_state();

// Prototypes for the reference banking system
void shadow_open_account(int id, int n);
void shadow_close_account(int id, int n);
void shadow_deposit(int id, int n, int amount);
void shadow_withdraw(int id, int n, int amount);
void shadow_get_balance(int id, int n);
void shadow_transfer(int id, int from, int to, int amount);
void shadow_report_balances(int id);
extern char* bank_name;

char** tokenize(char* str, int* n);
void test_tokenize();
void random_sleep(double min, double max);
unsigned long long gettime_usecs();

// Wrapper
void* Malloc(size_t n);

#endif
