#ifndef QUEUE_H
#define QUEUE_H

/*
 * A queue data structure, implemented as a doubly linked list.
 * Normal push onto the back, pop from the front, but allows the reverse as well.
 */

typedef struct queue *Queue;
typedef struct QueueItem *QueueItem;

struct queue {
  QueueItem front;
  QueueItem back;
  int size;
};

struct QueueItem {
  void *data;
  Queue queue;
  QueueItem next;
  QueueItem prev;
};

/* Create a new queue */
Queue q_new(void);

/* Add an item to the end of the queue */
QueueItem q_add(Queue queue, void *data);

/* Add an item to the front of the queue */
QueueItem q_add_to_front(Queue queue, void *data);

/* Remove an item from the queue it's in */
void *q_delete(QueueItem item);

/* Pop the next element off the front of the queue and return the data */
void *q_next(Queue queue);

/* Return the data in the first node in the queue.  Does _not_ pop it off. */
void *q_get_front(Queue queue);

/* Return the data in the last node in the queue.  Does _not_ remove it. */
void *q_get_back(Queue queue);

/* Free all the nodes in the queue. */
void q_free(Queue queue);

/* Print the data pointers in each queue node. */
void q_print(Queue queue);

/* Return the number of items in the queue*/
int q_size(Queue queue);

/* Return 1 if the queue is empty, 0 otherwise */
int q_empty(Queue queue);

#endif
