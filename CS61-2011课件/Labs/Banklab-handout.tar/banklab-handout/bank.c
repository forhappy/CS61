/*
 * bank.c -- bank simulator--most of the synchronization logic goes here.
 * Fall 2010 CS61 Lab 5.
 *
 * <Put your name(s) and login ID(s) here>
 *
 *  NOTE: You should NOT MODIFY any of the code in this file.  You should only ADD code.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <time.h>
#include <errno.h>
#include <pthread.h>
#include <semaphore.h>

#include "bank.h"
#include "backend.h"

/*************************************************************
 * Global state: add any type definitions/state you want shared by all
 * your threads here.
 *************************************************************/


// A value from locking_types (see bank.h)
int locking_type = MULTI_READ_LOCKS;

// Set by the -u flag; if 1, you should report suspicious transfers.
int do_suspicious_reporting = 0;

/* A buffer and associated indices where the bank should put suspicious
 * operations before notifying the thread that deals with them. */
#define SUSPICIOUS_BUFFER_LEN 16
operation *suspicious_op_buffer[SUSPICIOUS_BUFFER_LEN];
int producer_index; 
int consumer_index;

void log_suspicious_transfer(operation *op);

/*
 * Initialize any state you need here.  Will be called before any of the
 * atm threads are started.
 */
void init_bank() {
    producer_index = 0;
    consumer_index = 0;

    /* Add your initialization code here */

}

/*
 * Create account number n with initial balance 0.  Return 0 on
 * success, or ACCOUNT_EXISTS if account already exists.
 */
int open_account(int id, int n) {
    int result;


    result = do_open_account(id, n);

    
    return result;
}

/*
 * Delete account number n, returning amount of money left.  Return
 * UNKNOWN_ACCOUNT if account doesn't exist (was never created, or has
 * already been closed).
 * Any transactions involving this account that are running before this call
 * should be allowed to finish before the account is closed.  
 */
int close_account(int id, int n) {
    int result;

    result = do_close_account(id, n);


    return result;
}


/*
 * Deposit amount into account n.  Return new balance on success, or
 * UNKNOWN_ACCOUNT if account doesn't exist.
 */
int deposit(int id, int n, int amount) {
    int result;


    result = do_deposit(id, n, amount);


    return result;
}


/*
 * Withdraw amount from account n.  Return new balance on success, or
 * UNKNOWN_ACCOUNT if account doesn't exist.  Return
 * INSUFFICIENT_FUNDS if the balance is less than amount.
 */
int withdraw(int id, int n, int amount) {
    int result;


    result = do_withdraw(id, n, amount);


    return result;
}


/*
 * Return the balance in account n.  Return 0 on success, or
 * UNKNOWN_ACCOUNT if account doesn't exist.
 */
int get_balance(int id, int n) {
    int result;


    result = do_get_balance(id, n);


    return result;
}


/*
 * Allocate space for a new operation struct, fill it in, add it to
 * the suspicious_op_buffer, and then notify the handler thread that
 * there's something fishy going on.
 */
void report_suspicious_transfer(int id, int from, int to, int amount) {
    operation *op = Malloc(sizeof(struct operation));
    op->id = id;
    op->type = OP_TRANSFER;
    op->account = from;
    op->account2 = to;
    op->amount = amount;


    // Better have some kind of synchronization mechanism here.
    suspicious_op_buffer[producer_index] = op;
    producer_index = (producer_index + 1) % SUSPICIOUS_BUFFER_LEN;

    // Will need to notify the suspicious activity thread that the buffer changed.
}

/*
 * Check whether a transfer is worth investigating/logging.
 */
int transfer_is_suspicious(int result, int amount) {
    return (result > 0 && amount >= result && amount > 100);
}

/*
 * Transfer amount from account "from" to account "to".  Return
 * remaining balance in "from" account on success, or UNKNOWN_ACCOUNT
 * if either doesn't exist.  Return INSUFFICIENT_FUNDS if "from" has
 * balance less than amount.
 *
 * If do_suspicious_reporting is 1 and the transfer is suspicious (as
 * determined by the stunningly named transfer_is_suspicious() function above),
 * add it to the report buffer.
 */
int transfer(int id, int from, int to, int amount) {
    int result;


    result = do_transfer(id, from, to, amount);

    if (do_suspicious_reporting && transfer_is_suspicious(result, amount)){
        report_suspicious_transfer(id, from, to, amount);
    }
    

    return result;
}


/*
 * Return a Queue of balance structs, one for each account in the
 * system.  Note that this report must be consistent with the state of
 * the system at a particular point--if there have been $X deposits
 * and $Y withdrawals so far, the total must be $X-$Y, for example.
 * (This means that you can't allow the state of any account to change
 * once you start to generate the report).
 *
 * It is the caller's responsibility to free the queue.
 */
Queue report_balances(int id) {
    Queue result;


    result = do_report_balances(id);


    return result;
}

/***************************************************/

/*
 * The function for the suspicious activity thread.  Waits for to be
 * notified about suspicious looking deposits and transfers, logs them
 * using log_suspicious_transfer().
 */
void* suspicious_activity_thread(void *arg) {
    while(1){
        operation *op;


        // Better have some kind of synchronization mechanism here.
        op = suspicious_op_buffer[consumer_index];
        consumer_index = (consumer_index + 1) % SUSPICIOUS_BUFFER_LEN;


        log_suspicious_transfer(op);
    }
}

/* Print the suspicious operation and free the memory for the struct */
void log_suspicious_transfer(operation *op) {
    bank_printf("[%d] SUSPICIOUS TRANSFER from %d to %d: $%d\n",
                op->id, op->account, op->account2, op->amount);
    free(op);
}


/*****************************************************
 * Helper routines for your implementation go here
 *****************************************************/

