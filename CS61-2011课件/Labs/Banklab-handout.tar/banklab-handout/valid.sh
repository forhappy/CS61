#!/bin/bash

# Usage: valid.sh logfile

if [ -z $1 ]
then
    echo "Usage: valid.sh logfile"
    exit
fi

grep REFERENCE $1 | sed 's/REFERENCE: *//;s/</[/;s/>/]/' | tr "a-z" "A-Z" | sort > $1.ref

grep GSB $1 | sed 's/GSB: *//;s/</[/;s/>/]/' | tr "a-z" "A-Z" | sort > $1.gsb

echo "Running 'diff $1.ref $1.gsb'..."
diff $1.ref $1.gsb
echo "Done"