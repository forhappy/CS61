/* 
 * bank.h
 * Fall 2010 CS61 Lab 5.
 */

#ifndef _BANK_H_
#define _BANK_H_

#include "queue.h"

enum status { ACCOUNT_EXISTS = -1, UNKNOWN_ACCOUNT = -2, INSUFFICIENT_FUNDS = -3};

enum locking_types {
    NO_LOCKS = 0,
    BIG_LOCK = 1,
    FINE_GRAINED_LOCKS = 2,
    MULTI_READ_LOCKS = 3
};


typedef struct account {
    int valid;
    int balance;
} account;

typedef struct balance {
    int n;  // account number
    int amount;  // balance
} balance;

// Used for reporting suspicious operations
typedef struct transfer_info {
    int from;
    int to;
    int amount;
} transfer_info;

/* Defines a banking operation */
typedef struct operation {
    int id;   
    int type;  // one of the OP_XXX constants
    int account;
    int account2; // for transfers only -- the "to" account
    int amount;   // if applicable
} operation;

/* Different operation types */
enum optype {
    OP_OPEN,
    OP_CLOSE,
    OP_BALANCE,
    OP_DEPOSIT,
    OP_WITHDRAW,
    OP_REPORT,
    OP_TRANSFER
};

/* Per thread info */
typedef struct atm_info {
    int id;
    Queue requests;
    int request_delay_ms;
} atm_info;


enum constants {
    MAX_ACCOUNTS = 50,
    DEFAULT_NUM_THREADS = 3,
    DEFAULT_REQUEST_DELAY_MS = 100,
    MAXLINE = 1024       /* maximum characters in single trace line */
};


/* Functions that need proper sync added */
void init_bank();

int open_account(int id, int n);
int close_account(int id, int n);
int deposit(int id, int n, int amount);
int withdraw(int id, int n, int amount);
int get_balance(int id, int n);
int transfer(int id, int from, int to, int amount);
Queue report_balances(int id);
void report_suspicious_transfer(int id, int from, int to, int amount);
void* suspicious_activity_thread(void* arg);

/* Functions that do the actual work, but without locking */
int do_open_account(int id, int n);
int do_close_account(int id, int n);
int do_deposit(int id, int n, int amount);
int do_withdraw(int id, int n, int amount);
int do_get_balance(int id, int n);
int do_transfer(int id, int from, int to, int amount);
Queue do_report_balances(int id);
void do_log_suspicious_activity(transfer_info t);

/* provided helper routines */
void sync_printf(const char* format, ...);
void bank_printf(const char* format, ...);
void ref_printf(const char* format, ...);
void fatal_error(char* format, ...);
void unix_error(char* msg);
void check_range(int val, int min, int max, char* varname);

int transfer_is_suspicious(int result, int amount);


#endif
